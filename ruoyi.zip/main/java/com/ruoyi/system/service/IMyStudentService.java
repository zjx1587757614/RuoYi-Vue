package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.MyStudent;

/**
 * 学生信息Service接口
 * 
 * @author ruoyi
 * @date 2021-09-28
 */
public interface IMyStudentService 
{
    /**
     * 查询学生信息
     * 
     * @param id 学生信息主键
     * @return 学生信息
     */
    public MyStudent selectMyStudentById(Long id);

    /**
     * 查询学生信息列表
     * 
     * @param myStudent 学生信息
     * @return 学生信息集合
     */
    public List<MyStudent> selectMyStudentList(MyStudent myStudent);

    /**
     * 新增学生信息
     * 
     * @param myStudent 学生信息
     * @return 结果
     */
    public int insertMyStudent(MyStudent myStudent);

    /**
     * 修改学生信息
     * 
     * @param myStudent 学生信息
     * @return 结果
     */
    public int updateMyStudent(MyStudent myStudent);

    /**
     * 批量删除学生信息
     * 
     * @param ids 需要删除的学生信息主键集合
     * @return 结果
     */
    public int deleteMyStudentByIds(Long[] ids);

    /**
     * 删除学生信息信息
     * 
     * @param id 学生信息主键
     * @return 结果
     */
    public int deleteMyStudentById(Long id);
}
